package sg.edu.nus.iss.mcp.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McpServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
